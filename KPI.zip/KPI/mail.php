<?php

$name =
$service = $_POST['quote'];
$name    = $_POST['name'];
$phone   = ($_POST['phone'];
$email   = ($_POST['email'];
$message = ($_POST['message']);
$fromPage = ($_POST['hiddeninput'];

$mailheader = "From:" .$name."<" .$email.">\r\n";

$recipient = "nyikomashakeni26@gmail.com";

mail($recipient, $subject, $message, $mailheader)
or die("Error!");

echo'message sent';
?>
