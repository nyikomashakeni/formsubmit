<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';

    if (!empty($email) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Email destination (YOUR email)
        $to = "info@khamelapropertyinvestment.co.za"; // Replace with your actual email address
        $subject = "New Newsletter Subscriber";
        $message = "A new user has subscribed to your newsletter:\n\nEmail: $email";
        $headers = "From: noreply@khamelapropertyinvestment.co.za\r\n";
        $headers .= "Reply-To: $email\r\n";

        if (mail($to, $subject, $message, $headers)) {
            echo "Thank you for subscribing!";
        } else {
            echo "Failed to subscribe. Please try again.";
        }
    } else {
        echo "Invalid email address.";
    }
} else {
    echo "Invalid request.";
}
?>
